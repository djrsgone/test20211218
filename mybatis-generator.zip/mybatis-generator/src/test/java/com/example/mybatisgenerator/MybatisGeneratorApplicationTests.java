package com.example.mybatisgenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybatisGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
